var _z = {
	each: $each, setup: $setup, route: $route,
	getlSVal: getlSValue, setlSVal: setlSValue, fall: fallback,
	append: function(el, nodes) { $nodeUtil('append', el, nodes) },
	prepend: function(el, nodes) { $nodeUtil('prepend', el, nodes) },
	after: function(el, nodes) { $nodeUtil('after', el, nodes) },
	before: function(el, nodes) { $nodeUtil('before', el, nodes) },
	replace: function(el, nodes) { $nodeUtil('replace', el, nodes) },
	remove: function(el, nodes) { $nodeUtil('remove', el, nodes) }
}
function $each(obj, Fn) {
	var el = typeof obj === 'string' ? document.querySelectorAll(obj) : obj;
	Array.prototype.slice.call(el, 0).forEach(Fn)
}
function $setup(obj, attr, events) {
	var el = typeof obj === 'string' ? document.createElement(obj) : obj;
	if (attr) {
		for (var key in attr) {
			attr[key] === undefined ? el.removeAttribute(key) :
			key === 'html'    ? el.innerHTML   = attr[key] :
			key === 'text'    ? el.textContent = attr[key] :
			key === 'value'   ? el.value       = attr[key] :
			key === 'checked' ? el.checked     = attr[key] :
			el.setAttribute(key, attr[key]);
		}
	}
	if (events) {
		for (var key in events) {
			el.addEventListener(key, events[key], false);
		}
	}
	return el;
}
function $nodeUtil(p, el, nodes) {
	var i, node, Child, Parent = el.parentNode;
	if (typeof el === 'string')
		el = document.querySelector(el);
	if (nodes && !Array.isArray(nodes))
		nodes = [nodes];
	switch (p.toLowerCase()) {
		case 'append':
			for (i = 0, len = nodes.length; i < len; i++) {
				if (nodes[i])
					el.appendChild(nodes[i]);
			}
			break;
		case 'remove':
			$each(el, function(child) {
				child.parentNode.removeChild(child);
			});
			break;
		case 'replace':
			Parent.replaceChild(nodes[0], el);
			break;
		default:
			switch (p.toLowerCase()) {
				case 'after': Child = el.nextSibling;
					break;
				case 'before': Child = el;
					break;
				case 'prepend': Child = el.childNodes[0], Parent = el;
			}
			for (i = 0; node = nodes[i++];) {
				Parent.insertBefore(node, Child);
			}
	}
}
function $route(el, Fn) {
	while (el) {
		var tn = (typeof Fn === 'string' ? el.querySelector(Fn) : Fn(el));
		if (tn)
			return (typeof tn === 'object' ? tn : el);
		el = el.parentNode;
	}
}
function probeStore(name, val, sess) {
	var stor = sess ? sessionStorage : localStorage;
	try {
		stor.setItem(name, val);
	} catch(e) {
		stor.removeItem(name);
		stor.setItem(name, val);
	}
}
function setlSValue(name, value, sess) {
	if (typeof name === 'object') {
		for (var key in name) {
			probeStore(key, (name[key] === null ? value : name[key]), sess);
		}
	} else {
		probeStore(name, value, sess);
	}
}
function getlSValue(name, def, sess) {
	var stor = sess ? sessionStorage : localStorage;
	if (name in stor) {
		var v = stor.getItem(name);
		v = v == 'false' ? false : 
			v == 'true' ? true : v;
		return v;
	} else {
		probeStore(name, def, sess);
		return def;
	}
}
function fallback(e) {
	if (e.preventDefault)
		e.preventDefault();
	else
		e.returnValue = false;
}