// ==UserScript==
// @name    		Hanabira MagicApp
// @namespace   	magicode
// @description 	--
// @homepage		
// @updateURL   	
// @downloadURL 	
// @include 		*dobrochan.*/*/res/*.xhtml*
// @version 		1.0-pre
// @run-at  		document-start
// @grant   		none
// ==/UserScript==
var commonExt = document.createElement("style");
commonExt.textContent = 'ul,ol{margin:0;padding:0 0 0 20px;list-style-position:inside;}body{margin:0;padding:8px;margin-bottom:auto;}.description{font-size:.8em;}.subtitle{font-size:.6em;}.fileinfo{text-align:left;margin:0 20px 2px 20px;font-size:.8em;color:inherit;}.limited{max-width:360px;}.file .fileinfo{margin:0 0 2px 0;padding:0;}.file{float:left;margin:0 20px;}.highlight,.reply{padding:2px 1em 0 2px;box-shadow:0 1px 2px rgba(0,0,0,0.2);}.reply,.popup,.post-error{-webkit-border-radius:5px;}.popup{box-shadow:5px 5px 10px rgba(0,0,0,0.4);}form.reply{padding:3px;}.banner{padding:7px 0;}#reply-replyText{margin:5px 5px 0 5px;width:98%;}#fieldtable table{padding-top:0;margin-top:0;}.popup{border-color:#000;padding:3px;position:absolute;}.post-error{background:#E04000;color:#FFF;text-align:center;}.thumb,img,a{border:none;}.highlight{border-style:dashed;border-width:2px;-webkit-border-radius:6px;}.abbrev{padding:0 0 0 20px;color:#666;}.postbody{padding:.5em 20px;}.message{vertical-align:top;text-align:inherit;}div p,.thumb,a{padding:0;margin:0;}a{cursor:pointer;}a:focus{outline:0;}label,label input,.reflink,.reflink a{text-align:left;}.icon{background-repeat:no-repeat;background-position:0px center;cursor:pointer;}.icon input{position:absolute;left:-9001px;}.transparent{border:none;background:none!important;box-shadow:none!important;}label{margin-left:.2em;}.label{display:inline;}.cpanel,.abbrev a,.reflink a,.hideinfo a{text-decoration:none;}pre{margin:.4em 0;}.hideinfo{font-size:.8em;}.rightaligned{text-align:right;}.theader,.passvalid{text-align:center;padding:2px;clear:both;margin-bottom:.5em;box-shadow:inset 0 1px 2px rgba(0,0,0,0.2);font-weight:bold;-webkit-border-radius:5px;}.adminbar{clear:left;float:left;}.stylebar{clear:right;float:right;}.logo{clear:both;font-size:2em;}textarea{resize:both;}.textarea-ext{vertical-align:top;float:right;font-family:monospace;}.textarea-ext a{color:inherit;}.postblock{padding-left:7em;}#reply-tremail .postblock{padding-right:.5em;}.userdelete{float:right;text-align:center;white-space:nowrap;}.postarea table{margin:0px auto;text-align:left;}.footer{text-align:center;font-size:12px;font-family:serif;margin:2em 0 0 0;}.dellist{font-weight:bold;text-align:center;}.delbuttons{text-align:center;padding-bottom:4px;}.postlists{background:#FFF;width:100%;padding:0;color:#800000;}.postername,.replytitle,.postblock{font-weight:bold;}.doubledash{vertical-align:top;clear:both;float:left;}.replytitle{font-size:1.2em;}.postbody blockquote{background:inherit;margin:0;color:#789922;padding:.3em 0;}.postbody blockquote blockquote{color:#406010;margin:0;}.postbody blockquote blockquote blockquote{color:#204010;margin:0;}.spoiler,.spoiler a,.spoiler blockquote,.spoiler blockquote blockquote,.spoiler blockquote blockquote blockquote{transition:all .1s ease;}.spoiler a:hover,.spoiler:hover{box-shadow:none;}.spoiler blockquote:hover{color:#789922!important;}.spoiler blockquote blockquote:hover{color:#406010!important;}.spoiler blockquote blockquote blockquote:hover{color:#204010!important;}hr{border-style:none none solid;border-color:rgba(0,0,0,0.3);box-shadow:0 1px 0 #fff;}.nothumb{background-color:#FFF;border-style:dotted;margin:.3em .5em;}.rules{margin:0 auto;font-size:.9em;}#code_div{display:block;}#code_div,#code_edit,#code_view,#code_edit_ta,.jcrop-tracker{width:100%;height:100%;}.paginator-arrow{font-size:1.5em;text-decoration:none;font-weight:bold;}.document h1{font-size:1.2em;font-weight:bold;}.document ol{padding-top:5px;}.document blockquote{margin-top:8px;margin-bottom:5px;}.privacy-warning{border:2px #FF0000 dashed;font-size:1.2em;}.waiting0{background-image:url(\'/images/waiting0.gif\');}.waiting1{background-image:url(\'/images/waiting1.gif\');}.waiting2{background-image:url(\'/images/waiting2.gif\');}.delete,.delete-file{background-image:url(\'/images/delete.png\');}.checked{background-image:url(\'/images/delete_selected.png\');}.hide{background-image:url(\'/images/hidethread.png\');}.signed{background-image:url(\'/images/signed-on.png\');}.unsigned{background-image:url(/images/signed-off8.png);}.close{background-image:url(\'/images/close.png\');}.reply_{background-image:url(/images/reply.png);}.quote{background-image:url(/images/quote.png);}.add_{background-image:url(/images/music/add.png);}.play_{background-image:url(/images/music/play.png);}.view_{background-image:url(/images/view.png);}.edit_{background-image:url(/images/edit.gif);}.search_google{background-image:url(/images/google.png);}.search_iqdb{background-image:url(/images/booru.png);}.logodobleft{background-image:url(/css/img/dobleft.png) top right no-repeat;width:250px;height:674px;}.logodobright{background-image:url(/css/img/looongdobright.png) bottom left no-repeat;padding-left:30px;text-align:left;width:250px;}.names td{text-align:center;background:#EEAA88;color:#600000;padding:0 5px;}.values td{text-align:center;background:#F0E0D6;color:#600000;text-decoration:none!important;padding:0 5px;}td.logo,td>.logo{font-size:1.5em;}.ipmark{max-height:16px;}.threadlist{vertical-align:top;text-align:center;border-left:1px solid #bbb;padding-left:20px;}.alternate{display:none;}.imported{color:#117743;}.exported{color:#EE1105;}.imported a,.exported a{text-decoration:underline;}.revision-table{border-spacing:0;}.revision-header-row td{padding-left:5px;font-size:120%;background-color:#DDD;}.revision-header-index{font-size:140%!important;font-weight:bold;}.revision-content-row td{padding-left:20px;padding-right:15px;padding-bottom:10px;}.revision-content-row ins{background-color:#D1E1AD;color:#405A04;text-decoration:none;}.revision-content-row del{background-color:#E5BDB2;color:#A82400;text-decoration:line-through;}.reputation-positive{color:#007700;font-weight:bold;}.reputation-negative{color:#770000;font-weight:bold;}#player_container{position:relative;background-color:#eee;width:418px;height:80px;border:1px solid #009be3;}#player_container ul#player_controls{list-style-type:none;padding:0;margin:0;}#player_container ul#player_controls li{overflow:hidden;text-indent:-9999px;}#player_play,#player_pause{display:block;position:absolute;left:48px;top:20px;width:40px;height:40px;cursor:pointer;}#player_play{background:url("/images/music/icons.png") 0 0 no-repeat;}#player_play.jqjp_hover{background:url("/images/music/icons.png") -41px 0 no-repeat;}#player_pause{background:url("/images/music/icons.png") 0 -42px no-repeat;}#player_pause.jqjp_hover{background:url("/images/music/icons.png") -41px -42px no-repeat;}#ctrl_prev{position:absolute;left:20px;top:26px;background:url("/images/music/icons.png") 0 -112px no-repeat;width:28px;height:28px;cursor:pointer;}#ctrl_prev:hover{background:url("/images/music/icons.png") -29px -112px no-repeat;}#ctrl_prev.disabled{background:url("/images/music/icons.png") -58px -112px no-repeat;cursor:default;}#ctrl_next{position:absolute;left:88px;top:26px;background:url("/images/music/icons.png") 0 -141px no-repeat;width:28px;height:28px;cursor:pointer;}#ctrl_next:hover{background:url("/images/music/icons.png") -29px -141px no-repeat;}#ctrl_next.disabled{background:url("/images/music/icons.png") -58px -141px no-repeat;cursor:default;}#player_stop{position:absolute;left:126px;top:26px;background:url("/images/music/icons.png") 0 -83px no-repeat;width:28px;height:28px;cursor:pointer;}#player_stop.jqjp_hover{background:url("/images/music/icons.png") -29px -83px no-repeat;}#player_progress{position:absolute;left:164px;top:32px;background-color:#eee;width:122px;height:15px;}#player_progress_load_bar{background:url("/images/music/bar_load.png") top left repeat-x;width:0px;height:15px;cursor:pointer;}#player_progress_load_bar.jqjp_buffer{background:url("/images/music/bar_buffer.png") top left repeat-x;}#player_progress_play_bar{background:url("/images/music/bar_play.png") top left repeat-x;width:0px;height:15px;}#player_volume_min{position:absolute;left:296px;top:32px;background:url("/images/music/icons.png") 0 -170px no-repeat;width:18px;height:15px;cursor:pointer;}#player_volume_max{position:absolute;left:368px;top:32px;background:url("/images/music/icons.png") 0 -186px no-repeat;width:18px;height:15px;cursor:pointer;}#player_volume_min.jqjp_hover{background:url("/images/music/icons.png") -19px -170px no-repeat;}#player_volume_max.jqjp_hover{background:url("/images/music/icons.png") -19px -186px no-repeat;}#player_volume_bar{position:absolute;left:314px;top:37px;background:url("/images/music/volume_bar.png") repeat-x top left;width:46px;height:5px;cursor:pointer;}#player_volume_bar_value{background:url("/images/music/volume_bar_value.png") repeat-x top left;width:0px;height:5px;}#play_time,#total_time{position:absolute;left:164px;top:49px;width:122px;font-size:.8em;font-style:oblique;}#total_time{text-align:right;}#playlist_list{width:418px;}#playlist_list ul{list-style-type:none;padding:10px 20px 20px 20px;margin:0 0 10px 0;background-color:#ddd;border:1px solid #009be3;border-top:none;width:378px;font-size:.9em;}#playlist_list li{padding:4px 0 4px 20px;border-bottom:1px solid #eee;cursor:pointer;}#playlist_list li.playlist_current{color:#0d88c1;list-style-type:square;list-style-position:inside;padding-left:6px;cursor:default;}#playlist_list li.playlist_hover{color:#0d88c1;}.jcrop-holder{text-align:left;}.jcrop-vline,.jcrop-hline{font-size:0;position:absolute;background:white url(/images/jcrop.gif) top left repeat;}.jcrop-vline{height:100%;width:1px!important;}.jcrop-hline{width:100%;height:1px!important;}.jcrop-handle{font-size:1px;width:7px!important;height:7px!important;border:1px #eee solid;background-color:#333;}.custom .jcrop-vline,.custom .jcrop-hline{background:yellow;}.custom .jcrop-handle{border-color:black;background-color:#C7BB00;-webkit-border-radius:3px;}#admin_delete_panel{position:fixed;z-index:4000;bottom:0;top:auto;background-color:#CCC;border:solid #333 1px;width:80%;}#replyform{margin:2px 1em;}.delete,.delete-file{background-image:url(/images/delete.futaba.png);}.checked{background-image:url(/images/delete_selected.png);}.hide{background-image:url(/images/hidethread.futaba.png);}.close{background-image:url(/images/close.futaba.png);}.reply_{background-image:url(/images/reply.futaba.png);}.quote{background-image:url(/images/quote.futaba.png);}.add_{background-image:url(/images/music/add.futaba.png);}.play_{background-image:url(/images/music/play.futaba.png);}.remove_{background-image:url(/images/music/remove.futaba.png);}.icon{font-size:1.25em;}body{background-color:#FFFFEE;color:#600000;}.fileinfo{color:#600000;}.reply,.highlight,.popup{background-color:#F0E0D6;color:#600000;}.oppost{background-color:#FFFFEE;}.highlight{border-color:#FF5500;}.reply{border-color:#DDCCC5;}a{color:#0000EE;}.reflink a{color:inherit;}a:hover{color:#DD0000;}.adminbar b{font-weight:normal;}.theader,.passvalid{background:#E04000;color:#FFF;}.logo{text-align:center;color:#600000;}.postblock{background:#EEAA88;color:#600000;}.managehead{background:#F0E0D6;}.postername{color:#117743;}.postertrip{color:#228854;}.replytitle{color:#CC1105;}dl.menu dd,dl.menu dt,.pages{border:solid 1px #DDCCC5;}dl.menu dt{background:#F0E0D6;}.spoiler,.spoiler a,.spoiler blockquote,.spoiler blockquote blockquote,.spoiler blockquote blockquote blockquote{background:#F0D0B6;color:#F0D0B6;box-shadow:1px 1px 0px #D1C2BD;}.spoiler:hover,.spoiler a:hover{color:#600000;}.logline{background:#F0E0D6;}#code_view .highlight{background:#FFFFF7;}/*￿Main page*/.category{font-family:sans-serif;font-size:small;margin-bottom:8px;background:#F0E0D6;}.header{background:#EEAA88;color:#600000;padding:0px 3px 0px 3px;font-weight:bold;}.list{border-left:1px solid #F0E0D6;border-right:1px solid #F0E0D6;border-bottom:1px solid #F0E0D6;}.list div a{display:block;text-decoration:none;color:#600000;padding:0px 3px 0px 3px;}.list div a:hover{background:#FFFFEE;}.featuredimgtop{background-image:url(/css/img/imgtop.futaba.png);background-position:top;background-repeat:no-repeat;}.featuredimgbottom{height:300px;background-image:url(/css/img/imgbottom.futaba.png);background-position:bottom;background-repeat:no-repeat;}.newsbg{width:502px;background-color:#f0e0d6;}.newstop{background-image:url(/css/img/top.futaba.png);background-position:top;background-repeat:no-repeat;}.newsbottom{background-image:url(/css/img/bottom.futaba.png);background-position:bottom;background-repeat:no-repeat;}.newssize{padding:35px 40px 80px 45px;font-size:120%;}/* Player skin */#player_container{background-color:#FFFFEE;border:1px solid #FF9D00;}#player_play{background:url("/images/music/icons.futaba.png") 0 0 no-repeat;}#player_play.jqjp_hover{background:url("/images/music/icons.futaba.png") -41px 0 no-repeat;}#player_pause{background:url("/images/music/icons.futaba.png") 0 -42px no-repeat;}#player_pause.jqjp_hover{background:url("/images/music/icons.futaba.png") -41px -42px no-repeat;}#ctrl_prev{background:url("/images/music/icons.futaba.png") 0 -112px no-repeat;}#ctrl_prev:hover{background:url("/images/music/icons.futaba.png") -29px -112px no-repeat;}#ctrl_prev.disabled{background:url("/images/music/icons.futaba.png") -58px -112px no-repeat;cursor:default;}#ctrl_next{background:url("/images/music/icons.futaba.png") 0 -141px no-repeat;}#ctrl_next:hover{background:url("/images/music/icons.futaba.png") -29px -141px no-repeat;}#ctrl_next.disabled{background:url("/images/music/icons.futaba.png") -58px -141px no-repeat;cursor:default;}#player_stop{background:url("/images/music/icons.futaba.png") 0 -83px no-repeat;}#player_stop.jqjp_hover{background:url("/images/music/icons.futaba.png") -29px -83px no-repeat;}#player_progress{position:absolute;left:164px;top:32px;background-color:#FFFFEE;width:122px;height:15px;}#player_progress_load_bar{background:url("/images/music/bar_load.futaba.png") top left repeat-x;width:0px;height:15px;}#player_progress_play_bar{background:url("/images/music/bar_play.futaba.png") top left repeat-x ;width:0px;height:15px;}#player_volume_min{left:296px;top:32px;background:url("/images/music/icons.futaba.png") 0 -170px no-repeat;width:18px;height:15px;}#player_volume_max{left:368px;top:32px;background:url("/images/music/icons.futaba.png") 0 -186px no-repeat;width:18px;height:15px;}#player_volume_min.jqjp_hover{background:url("/images/music/icons.futaba.png") -19px -170px no-repeat;}#player_volume_max.jqjp_hover{background:url("/images/music/icons.futaba.png") -19px -186px no-repeat;}#player_volume_bar{left:314px;top:37px;background:url("/images/music/volume_bar.futaba.png") repeat-x top left;width:46px;height:5px;}#player_volume_bar_value{background:url("/images/music/volume_bar_value.futaba.png") repeat-x top left;width:0px;height:5px;}#playlist_list{width:418px;}#playlist_list ul{list-style-type:none;padding:10px 20px 20px 20px;margin:0 0 10px 0;background-color:#F0E0D6;border:1px solid #FF9D00;border-top:none;width:378px;font-size:.9em;}#playlist_list li{padding:4px 0 4px 20px;border-bottom:1px solid #FFFFEE;cursor:pointer;}#playlist_list li.playlist_current{color:#FF9D00;list-style-type:square;list-style-position:inside;padding-left:6px;cursor:default;}#playlist_list li.playlist_hover{color:#FF9D00;}\
input[type="text"],input[type="password"],textarea{padding:4px!important} .sage-mark{position:relative;right:1em;top:5px}';
document.head.appendChild(commonExt);

//var srf = document.createElement("script");
//srf.textContent = 'var link_template, replies_map = {};\n'+
//						'ShowRefPost = '+ ShowExRefPost.toString() +';';
//document.head.appendChild(srf);
window.stop();
var script = document.createElement("script");
script.textContent = '('+ MagicApp.toString() +')();';
document.head.appendChild(script);

function MagicApp() {
	
	if (getlSValue('activew') == undefined) setlSValue('activew', true);
	if (!getlSValue('rating')) setlSValue('rating', "sfw");
	if (!getlSValue('updint')) setlSValue('updint', "30");
	if (!getlSValue('lang')) setlSValue('lang', "ru");
	
	var res = new RegExp(/\/(\w+)\/res\/(\d+).?/).exec(location.pathname),
		desk = res[1],
		threadId = res[2];
	//var thread = document.getElementById('thread_' + threadId);
	var postNode = document.getElementsByClassName('post');
	var timer_id = 0;
	var unreadCount = 0;
	var thread_updating = false;
	window.onfocus = function(event) {
		setlSValue('activew', true);
		Tinycon.setBubble(0);
		unreadCount = unreadCount * 0;
	}
	window.onblur = function(event) {
		setlSValue('activew', false);
	}
	var ru = getlSValue('lang') == "ru";
	var LC = {
		repl: ru ? "Ответ" : "Reply",
		file: ru ? "Фаил: " : "File: ",
		hide: ru ? "Скрыть" : "Hide",
		edit: ru ? "Изменить" : "Edit",
		view: ru ? "Просмотр" : "View",
		newp: ru ? " новых " : " new ",
		omit: ru ? " ответов " : " omited ",
		delp: ru ? " удаленных " : " deleted ",
		subscrb: ru ? "Отслеживать" : "Subscribe",
		updprog: ru ? "Обновление..." : "Updating...",
		updauto: ru ? "Автообновление" : "Autoupdate",
		postdel: ru ? 'Пост удалён.' : "Post is deleted.",
		loadnew: ru ? "Подгрузить посты" : "Load New Posts",
		mrk_to_del: ru ? "Отметить для удаления" : "Mark to delete",
		snd_notify: ru ? "Звуковое уведомление" : "Sound Notifications",
		fnd_src_wth: ru ? "Поискать оригинал в" : "Find source with",
		clck_img_to: ru ? " - Нажмите на картинку " : " - Click the image ",
		update_title: ru ? "Автоматически обновлять тред каждые %s% секунд" : "Automatically update thread every %s% seconds",
		snd_notify_title: ru ? "Оповещать о новых постах звуковым уведомлением" : "Add notification sound for new loaded posts",
		expd: ru ? "для увеличения" : "to expand",
		getf: ru ? ", чтобы скачать файл" : "to get file",
		line: ru ? " строк" : " line",
		page: ru ? " страниц" : " page",
		few: {
			'en': ru ? "" : "s",
			'ru': ru ? "а" : "",
			'u': ru ? "ы" : "\'s"
		},
		Month: {
			'01': ru ? " Январь "   : " January "   ,
			'02': ru ? " Февраль "  : " February "  ,
			'03': ru ? " Март "     : " March "     ,
			'04': ru ? " Апрель "   : " April "     ,
			'05': ru ? " Май "      : " May "       ,
			'06': ru ? " Июнь "     : " June "      ,
			'07': ru ? " Июль "     : " July "      ,
			'08': ru ? " Август "   : " August "    ,
			'09': ru ? " Сентябрь " : " September " ,
			'10': ru ? " Октябрь "  : " October "   ,
			'11': ru ? " Ноябрь "   : " November "  ,
			'12': ru ? " Декабрь "  : " December "
		},
		Weekday: {
			'0': ru ? " (Вс) " : " (Sun) " ,
			'1': ru ? " (Пн) " : " (Mon) " ,
			'2': ru ? " (Вт) " : " (Tue) " ,
			'3': ru ? " (Ср) " : " (Wed) " ,
			'4': ru ? " (Чт) " : " (Thu) " ,
			'5': ru ? " (Пт) " : " (Fri) " ,
			'6': ru ? " (Cб) " : " (Sat) " 
		}
	}
	$cid = function(pid) {
		var n = new RegExp(/(\d+)/).exec(pid);
		return n[0];
	}
	$setup = function (obj, attr, events) {
		var el = typeof obj == "string" ? document.createElement(obj) : obj;
		if (attr) {
			for (var key in attr) {
				key === 'html' ? el.innerHTML = attr[key] :
				key === 'text' ? el.textContent = attr[key] :
				key === 'value' ? el.value = attr[key] :
				el.setAttribute(key, attr[key]);
			}
		}
		if (events) {
			for (var key in events) {
				el.addEventListener(key, events[key], false);
			}
		}
		return el;
	}
	$append = function (el, nodes) {
		for(var i = 0, len = nodes.length; i < len; i++) {
			if(nodes[i]) {
				el.appendChild(nodes[i]);
			}
		}
	}
	$before = function (el, node) {
		el.parentNode.insertBefore(node, el);
	}
	$after = function (el, node) {
		el.parentNode.insertBefore(node, el.nextSibling);
	}
	$shide = function (obj, prop) {
		var el = typeof obj == "string" ? document.querySelector(obj) : obj,
			attr = el.getAttribute('style');
		console.log(attr)
		!attr || attr != prop ? el.setAttribute('style', prop) : el.removeAttribute('style');
	}
	$t = function(last) { return (new Date).getTime() - (last ? parseInt(last) : 0) }
	
	function getlSValue(name, def) {
		if (name in localStorage) {
			var v = localStorage.getItem(name);
			v = v == 'false' ? false : 
				v == 'true' ? true : v;
			return v;
		} else return def;
	}
	function setlSValue(name, value) {
		localStorage.setItem(name, value)
	}
	
	function getDataTime(jsonDT) {
		var date = new RegExp(/(\d+)\-(\d+)\-(\d+)\ (\d+\:\d+)(\:\d+)/).exec(jsonDT),
			year = date[1], month = date[2], day = date[3], hmin = date[4], sec = date[5],
			uDate = new Date(month +" "+ day +", "+ year +" "+ hmin + " GMT+0400"),
			Time = uDate.toLocaleTimeString(),
			Month = LC.Month[month],
			weekDay = LC.Weekday[uDate.getDay()];
		return day + Month + year + weekDay + (Time.length === 7 ? "0" + Time.slice(0, 4) : Time.slice(0, 5)) +'<span style="opacity:.6">'+ sec +'</span>';
	}
	
	function getJsonPosts(uri, Fn) {
		var apiReq = new XMLHttpRequest()
		apiReq.open('GET', uri, true);
		apiReq.send(null);
		apiReq.onreadystatechange = function() {
			if(apiReq.readyState !== 4) {
				return;
			}
			if(apiReq.status === 304) {
				alert('error');
			} else {
				try {
					var json = JSON.parse(apiReq.responseText);
				} catch(e) {
					Fn(1, e.toString(), null, this);
				} finally {
					if(json) {
						Fn(apiReq.status, apiReq.statusText, json, this);
					}
					Fn = null;
				}
			}
		}
	}
		
	function getHanabiraFile(file, pid, postId, len) {
		var name, fileattach, info, filebtns,
			src = file.src,
			imgW = file.metadata.width,
			imgH = file.metadata.height,
			thumb = file.thumb,
			thumbW = file.thumb_width,
			thumbH = file.thumb_height,
			type = file.type,
			fid = file.file_id,
			size = bytesMagnitude(file.size),
			rating = file.rating,
			filename = src.substring(src.lastIndexOf("/") + 1),
			maxRating = getlSValue('rating'),
			ext = filename.split('.').pop(),
			m = 0.01572;
		if (file.metadata["MIME Type"])
			type = file.metadata["MIME Type"].split('/')[0];
		if (desk === 'b' || desk === 'rf') {
			name = type == "image" ? thumb.substring(thumb.lastIndexOf("/") + 1).split('s')[0] +'.'+ ext :
					type == "video" ? file.metadata["File Name"] : fid.toString() + pid.toString() +'.'+ ext;
		} else {
			name = filename;
			if (len > 1 && filename.length > 17)
				name = filename.substring(0, 17) + '...';
		}
		thumb = rating === 'r-18g' && maxRating !== 'r-18g' ? 'images/r-18g.png' :
			rating === 'r-18' && (maxRating !== 'r-18g' || maxRating !== 'r-18') ? 'images/r-18.png' :
			rating === 'r-15' && maxRating === 'sfw' ? 'images/r-15.png' :
			rating === 'illegal' ? 'images/illegal.png' :
			file.thumb;
		if (thumb !== file.thumb) {
			thumbW = 200;
			thumbH = 200;
		}
		var btnSrch = '<a class="search_%i% icon" href="//url@'+ location.host +'/'+ src +'"><img src="/images/blank.png" title="'+ LC.fnd_src_wth +' %i%" alt="%i%"></a>\n';
		var btnEdit = '<a class="edit_ icon" href="/utils/%type%/edit/'+ fid +'/'+ pid +'%e%"><img src="/images/blank.png" title="'+ LC.edit +'" alt="✎"></a>\n';
		var btnView = '<a class="view_ icon" href="/utils/%type%/'+ fid +'/'+ pid +'"><img src="/images/blank.png" title="'+ LC.view +'" alt="☌"></a>\n';
		
		if (type == "image") {
			info = ext.slice(0, 1).toUpperCase() + ext.slice(1) +', '+ size +', '+ imgW +'x'+ imgH;
			filebtns = (len == 1 ? LC.clck_img_to + LC.expd : '') + '<br>' +
						btnEdit.replace('%type%', type).replace('%e%', '') +
						btnSrch.replace(/%i%/g, "google").replace('url@', 'www.google.com/searchbyimage?image_url=') +
						btnSrch.replace(/%i%/g, "iqdb").replace('url@', 'iqdb.org/?url=') + '</div>';
		} else {
			var meta, lines = file.metadata.lines, pages = file.metadata.pages, metatype = file.metadata.type,
				expd = (len == 1 ? LC.clck_img_to + LC.getf : '');
			if (type == "code")
				meta = lines + LC.line + (lines == 1 ? LC.few['ru'] : LC.few['en']);
			if (type == 'PDF')
				meta = imgW +'x'+ imgH +', '+ pages + LC.page + (pages == 1 ? LC.few['ru'] : LC.few['en']);
			filebtns = expd + '<br>' +
						btnEdit.replace('%type%', 'text').replace('%e%', '/edit') +
						btnView.replace('%type%', 'text') + '</div>';
			if (type == 'music') {
				var brate = (file.metadata.bitrate / 1000) + ' kbps';
				var srate = (file.metadata.sample_rate / 1000).toFixed(2) + ' kHz';
				var trlen = (file.metadata.length * m).toFixed(2).replace('.', ':');
				var trnam = file.metadata.artist +' - '+ file.metadata.album;
				meta = trlen +' @ '+ brate +' / '+ srate +'<br>'+ trnam +' / '+ file.metadata.title +' ['+file.metadata.tracknumber+'/'+file.metadata.totaltracks+']';
				filebtns = '<br><a class="add_ icon" onclick="add_to_playlist({\'name\': \'\', \'filename\': \'\', \'ext\': \'\', \'file_id\': 1462671, \'duration\': 419, \'path\': \'\'});"><img src="/images/blank.png" title="add" alt="add"></a>\n' +
				'<a class="play_ icon" onclick="play_at_playlist({\'name\': \'\', \'filename\': \'\', \'ext\': \'\', \'file_id\': 1462671, \'duration\': 419, \'path\': \'\'});"><img src="/images/blank.png" title="play" alt="play"></a>\n' + '</div>';
			}
			if (type == 'video') {
				metatype = file.metadata["File Type"];
				size = file.metadata["File Size"];
				meta = '';
			}
			info = metatype +', '+ size +', '+ meta;
		}
		var fileinfo = '<div class="fileinfo">'+ LC.file +'<a href="/'+ src +'" target="_blank" title="'+ filename +'">'+ name +'</a><br><em>'+ info +'</em>';
		var filethmb = '<a href="/'+ src +'" target="_blank"><img class="thumb" src="/'+ thumb +'" width="'+ thumbW +'" height="'+ thumbH +
						'" onclick="expand_image(event, '+ imgW +', '+ imgH +')" alt="'+ filename +'"></a>\n</div>';
		var filediv = '<div id="file_'+ postId +'_'+ fid +'" class="file">';
		return fileattach = (len == 1 ? fileinfo + filebtns + filediv + filethmb : filediv + fileinfo + filebtns + filethmb);
	}
	
	function getHanabiraPost(postJson) {
		if (window.HTMLAudioElement && play_sound) {
			new Audio("/src/mp3/1406/musbox.mp3").play();
		}
		if (!getlSValue('activew')) {
			unreadCount = unreadCount + 1;
			Tinycon.setBubble(unreadCount);
		}
		var i, html, postId = postJson.display_id,
			files = postJson.files,
			len = files.length,
			op = postJson.op,
			wrap = $setup((op ? 'div' : 'table'), {'id': 'post_'+ postId, 'class': (op ? 'oppost' : 'replypost') +' post'}, null);
		var delicon = '<a class="delete icon"><input type="checkbox" id="delbox_%pId%" class="delete_checkbox" value="'+ postJson.thread_id +
					'" name="%pId%"><img src="/images/blank.png" title="'+ LC.mrk_to_del +'" alt="✕"></a>\n';
		html = (op ? '' : '<tbody><tr><td class="doubledash">&gt;&gt;</td><td id="reply%pId%" class="reply">') +
				'<a name="i%pId%"></a>' +
				'<label>' + 
					(op ? '<a class="hide icon" onclick="hide_thread(event, \'%desk%\',%pId%);" href="/api/thread/%desk%/%pId%/hide.redir"><img src="/images/blank.png" title="'+ LC.hide +'" alt="﹅"></a>\n' +
						delicon + '<a class="unsigned icon" onclick="sign_thread(event, \'%desk%\',%pId%);"><img src="/images/blank.png" title="'+ LC.subscrb +'" alt="✩"></a>\n' : delicon) +
					(desk === 'mad' ? '<span class="iphash">' +
						'<span class="ipmark" style="background:rgba(0,0,0,.5)">&nbsp;</span><span class="ipmark" style="background:rgba(255,255,255,.5)">&nbsp;</span>' +
						'<span class="ipmark" style="background:rgba(25,25,25,.6)">&nbsp;</span><span class="ipmark" style="background:rgba(99,99,99,.6)">&nbsp;</span>' +
						'<span class="ipmark" style="background:rgba(175,175,175,.6)">&nbsp;</span></span>\n<img class="geoicon" src="/src/png/1408/polandball_kawaii_16.png" alt="(^ ^)" title="Polandball (^ ^)">\n' : '') +
					'<span class="replytitle">'+ postJson.subject +'</span>\n<span class="postername">'+ postJson.name +'</span> '+ getDataTime(postJson.date) +
				' </label>' +
				'<span class="reflink"><a onclick="Highlight(0, %pId%)" href="/%desk%/res/%tId%.xhtml#i%pId%">No.%pId%</a></span>\n' +
				'<span class="cpanel"><a class="reply_ icon" onclick="GetReplyForm(event, \'%desk%\', %tId%, %pId%)">' +
				'<img src="/images/blank-double.png" style="vertical-align:sub" title="'+ LC.repl +'" alt=">>"></a></span><br>';
		for (i = 0; i < len; i++) {
			html += getHanabiraFile(files[i], postJson.post_id, postId, len);
		}
		wrap.insertAdjacentHTML('afterbegin', html.replace(/%desk%/g, desk).replace(/%tId%/g, threadId).replace(/%pId%/g, postId) + 
			(len > 1 ? '<br style="clear: both">' : '') +'<div class="postbody">'+ postJson.message_html +'</div><div class="abbrev"></div>' +
			(op ? '' : '</td></tr></tbody>'));
		return [wrap, (op ? wrap.firstChild : wrap.firstChild.firstChild.lastChild)];
	}
	
	function getHanabiraAllPosts(event) {
		getJsonPosts('/api/thread/'+ desk +'/'+ threadId +'/all.json?message_html&new_format',
			function(status, sText, json, xhr) {
				var jpid, pnid, i, jsonPost = json.result.posts;
				if (event) {
					for (i = 0; jsonPost[i]; i++) {
						var temp = getHanabiraPost(jsonPost[i]);
						thread.appendChild(temp[0]);
						postCount.textContent = postNode.length + LC.omit;
						//genRefMap(postNode, null)
					}
				} else {
					for (i = 0; postNode[i] != undefined; i++) {
						pnid = $cid(postNode[i].id);
						jpid = !jsonPost[i] ? 0 : jsonPost[i].display_id;
						if (Number(pnid) != jpid) {
							if (Number(pnid) < jpid || jpid == 0) {
								postNode[i].querySelector('.doubledash').setAttribute('style', "display:inline");
								$setup(postNode[i], {'class': "deleted", 'style': 'opacity:.6'});
							}
							if (Number(pnid) > jpid && jpid > 0) {
								var Id = jpid.toString(),
									derefl = '<a style="text-decoration:none" href="#i'+ Id +'" onmouseover="ShowRefPost(event,\''+ desk +'\', '+ threadId +', '+ jpid +')" onclick="Highlight(event, \''+ jpid +'\')">&gt;&gt;'+ jpid +'</a>',
									dealp = document.getElementsByClassName('allow-posts')[0],
									deupd = document.getElementById('updater'),
									apnode = document.getElementById(postNode[i].id),
									temp = getHanabiraPost(jsonPost[i]);
								$before(apnode, temp[0]);
								if (!dealp)
									postCount.insertAdjacentHTML('afterend', '<span class="allow-posts" style="color:#666;font-size:14px"> | раскрытых: '+ derefl +'</span>');
								else
									dealp.insertAdjacentHTML('beforeend', ', '+ derefl);
							}
						}
					}
				}
			}
		);
	}
	
	function updateThread(event) {
		var lastElem = thread.lastElementChild,
			lastPost = lastElem.tagName === 'FORM' ? lastElem.previousElementSibling.id : lastElem.id;
		if(!lastElem) getHanabiraAllPosts(1);
		update.textContent = LC.updprog;
		getJsonPosts('/api/thread/'+ desk +'/'+ threadId +'/new.json?message_html&new_format&last_post='+ $cid(lastPost),
			function parseNewPosts(status, sText, json, xhr) {
				if(status !== 200 || json.error) {
					update.textContent = !json.error ? sText : json.error;
				} else {
					var i, lastOffset, temp,
						pCount = json.result.posts_count,
						tpcount = postNode.length,
						el = json.result.posts,
						len = el ? el.length : 0, 
						np = len;
					if (len > 0) {
						pCount = json.result.posts_count;
						for(i = 0; i < len; i++) {
							temp = getHanabiraPost(el[i]);
							thread.appendChild(temp[0]);
						}
						tpcount = tpcount + len;
					}
					if (tpcount != pCount) {
						getHanabiraAllPosts();
					}
					postCount.textContent = pCount + LC.omit;
					update.textContent = LC.loadnew;
				}
			}
		);
		if (!event)
			chek();
	}
	
	function chek() {
		if (autoupdate) {
			timer_id = setTimeout(updateThread, update_interval());
		} else if (!autoupdate) {
			timer_id = setTimeout(function quietThreadUpdate() {
				getJsonPosts('/api/thread/'+ desk +'/'+ threadId +'.json?new_format',
					function(status, sText, json, xhr) {
						if (json.result) {
							var c = new RegExp(/(\+|\-)(\d+)/g).exec(postCount.textContent);
							var i = json.result.posts_count - postNode.length,
							postNew = i > 0 ? '( +'+ i + LC.newp +')' :
									  i < 0 ? '( ' + i + LC.delp +')' : '';
							postCount.textContent = postNode.length + LC.omit + postNew;
						}
					}
				);
			}, update_interval());
		}
	}
	
	var updater = $setup('div', {'id': 'updater'}, null);
	var update = $setup('a', {'name': 'update'}, null);
	update.textContent = LC.loadnew;
	updater.appendChild(update);
	update.onclick = updateThread;
	
	var update_interval = function() {
		var i = getlSValue('updint') < 5 ? 30 : getlSValue('updint');
		return i * 1000
	}
	
	var autoupdate = getlSValue('auto') == undefined ? true : getlSValue('auto');
	var play_sound = getlSValue('sound') == undefined ? false : getlSValue('sound');
	var updtitle = function() {return LC.update_title.replace('%s%', getlSValue('updint'))};
	
	var playNotify = $setup('input', {'type': 'checkbox', 'id': 'sound', 'title': LC.snd_notify_title}, null);
	playNotify.checked = play_sound;
	playNotify.onclick = function() {
		play_sound = playNotify.checked;
		setlSValue('sound', play_sound);
	}
	
	var autoUpdate = $setup('input', {'type': 'checkbox', 'id': 'autoupdate', 'title': updtitle()}, null);
	autoUpdate.checked = autoupdate;
	autoUpdate.onclick = function() {
		autoupdate = autoUpdate.checked;
		setlSValue('auto', autoupdate);
		if (timer_id != 0) {
			clearTimeout(timer_id);
			timer_id = 0;
		}
		chek();
	}
	
	var setUpdInt = $setup('input', {'style': 'width:32px', 'name': 'int-upd', 'min': '15', 'max': '120', 'type': "number", 'value': getlSValue('updint')}, null);
	setUpdInt.oninput = function() {
		setlSValue('updint', this.value);
		autoUpdate.title = updtitle();
	}
	
	var body = document.createElement("body");
	var postCache = $setup('div', {'class': 'post-cache', 'style': 'display:none'}, null);
	var postCount = $setup('label', {'class': 'post-count', 'style': 'color:#666'}, null);
	var delForm = $setup('form', {'id': 'delete_form', 'action': '/b/delete', 'method': 'post'}, null);
	var thread = $setup('div', {'id': 'thread_'+ threadId, 'class': 'thread'}, null);
	mReplyForm = $setup('div', {'id': 'magicform', 'style': 'inline-block;text-align:left',
		'html': '<table class="code-snippet" border="0">'+
					'<tbody><tr><th class="code">Code</th><th class="result">Result</th></tr>'+
					'<tr><td class="code">'+
					'<textarea style="overflow: hidden; word-wrap: break-word; resize: horizontal; height: 103px; width: 141px;" cols="40" rows="5" name="bodyTextYes1" id="bodyTextYes1" onclick="this.focus();this.select()">&lt;textarea rows="3" cols="20"&gt;Enter your text here...&lt;/textarea&gt;</textarea>'+
					'<br><img class="icon" src="/pix/icons/popup_icon_3.png" title="Show code in popup window" onclick="codeInPopup(\'bodyTextYes1\',\'Desktop\');">'+
					'</td>'+
					'<td class="result">'+
					'<textarea style="width: 363px; height: 105px;" rows="3" cols="20">Enter your text here...</textarea>'+
					'</td></tr>'+
				'</tbody></table>'
		/*'<form enctype="multipart/form-data" action="/b/post/new.xhtml" style="inline-block;text-align:center" id="magicpostform" class="replyform">'+
					'<input name="thread_id" value="'+ threadId +'" type="hidden"><input name="task" value="post" type="hidden"><input id="scroll_to" name="scroll_to" value="" type="hidden">'+
					'<div>'+
					'<a class="delete icon" title="Убрать" onclick="$shide(magicReplyForm, \'display:none\')" ><img src="/images/blank.png" alt="Remove" style="vertical-align:middle;min-height:17px"></a>'+
						'<div>'+
							'<input name="name" size="30" placeholder="Анонимус" value="" type="text">'+
							'<span class="sage-mark" style="opacity:.4" onclick="$shide(this, \'opacity:.4\')"><img src="//ponyach.ru/css/images/niceroom.img/sage.svg"></span><input name="subject" size="30" maxlength="64" placeholder="Тема" value="" type="text">' +
						'</div>'+
						'<div><textarea placeholder="Текст сообщения " style="padding:0;resize:both" id="yukireplyText" name="message" cols="60" rows="6" onkeyup="$(this).css(\'height\', \'auto\' ); $(this).height(this.scrollHeight + 24);"></textarea></div>'+
				'</div></form>'
		
		
		'<input name="thread_id" value="'+ tid +'" type="hidden">
				<input name="task" value="post" type="hidden">
				<input id="scroll_to" name="scroll_to" value="'+ pid +'" type="hidden">' +
			'<table>
				<tbody>
					<tr id="trname">
						<td class="postblock"></td><td>
						<input name="name" size="30" placeholder="Анонимус" value="" type="text">' +
						'<span id="sage-btn" style="opacity:.4" onclick="$shide(this, \'opacity:.4\')"><img src="//ponyach.ru/css/images/niceroom.img/sage.svg"></span>
						<span style="float:right">&nbsp;
							<a class="delete icon" title="Убрать" onclick="$shide(magicReplyForm, \'display:none\')" >
								<img src="/images/blank.png" alt="Remove" style="vertical-align:middle;min-height:17px">
							</a>
						</span>
						</td>
					</tr>
					<tr style="display:none" id="trsage">
						<td class="postblock"></td><td></td></tr>
					<tr id="trsubject">
						<td class="postblock"></td><td>
						<input name="subject" size="30" maxlength="64" placeholder="Тема" value="" type="text">
						<input name="new_post" value="Отправить" type="submit">
						<span style="float:right">
							<span class="markup-buttons" style="float:right;text-align:right">' +
								'<a href="#" onclick="wmarkText(\'* \', \'\\n* \');return false" class="list icon" title="Список" style="border:none">&nbsp;<strong>◉</strong>&nbsp;</a> '+
								'<a href="#" onclick="wmarkText(\'$~\', \'~$\');return false" class="strike icon" title="Зачеркнутый"><img src="/src/svg/1405/~S-mark.svg" alt="\~\$"></a> '+
								'<a href="#" onclick="wmarkText(\'_\', \'_\');return false" class="italic icon" title="Курсивный"><img src="/src/svg/1405/i-mark.svg" alt="i"></a> '+
								'<a href="#" onclick="wmarkText(\'**\', \'**\');return false" class="bold icon" title="Жирный"><img src="/src/svg/1405/-b-mark.svg" alt="b"></a> '+
								'<a href="#" onclick="wmarkText(\'`\', \'`\');return false" class="code icon" title="Код"><img src="/src/svg/1405/[c]-mark.svg" alt="c"></a> '+
								'<a href="#" onclick="wmarkText(\'%%\', \'%%\');return false" class="spoiler icon" title="Спойлер">·<strong>%%</strong>·</a> '+
								'<a href="#" onclick="wmarkText(\'> \', \'\\n> \');return false" class="quote icon" title="Цитировать выделенное"><img src="/src/svg/1405/„q”-mark.svg" alt="q"></a>
							</span>' +
						'</td>
					</tr>
					<tr id="trmessage">
						<td class="postblock"></td><td>
							<textarea placeholder="Текст сообщения " style="padding:0;resize:both" id="yukireplyText" name="message" cols="60" rows="6" onkeyup="$(this).css(\'height\', \'auto\' ); $(this).height(this.scrollHeight + 24);"></textarea><br>
							<div id="gamePlaceholder"></div>
						</td>
					</tr>
					<tr id="trcaptcha">
					<td class="postblock"></td><td>
						<span><img alt="Капча" id="captcha-image" src="/captcha/'+ desk +"/"+ $t() +'.png" onclick="reload_captcha(event)" style="margin:2px;vertical-align:middle">&nbsp;
						<span onclick="yukiAttachCapcha(this)" class="yuki_clickable" title="Прикрепить капчу" style="color:#999">[+]</span></span><br>' +
						'<input autocomplete="off" id="captcha" name="captcha" size="30" onfocus="reload_captcha(event);" onkeypress="CaptchaProcess(event, \'ru\')" type="text" style="display:none">' +
					'</td></tr>
					<tr style="display: none;" id="trrempass">
						<td class="postblock"></td><td><input name="password" size="35" value="123" type="password">' +
			'</td></tr><tr id="trfile"><td class="postblock"></td><td id="files_parent"><input id="post_files_count" name="post_files_count" value="2" type="hidden">' +
			'<div id="file_1_div"><input id="dumb_file_field" onchange="yukiAddFile(event, this);" type="file" style="visiblity:hidden;width:0;height:0;position:absolute;left:-9001px" multiple>' +
			'<input value="Добавить файлы" type="button" onclick="this.previousElementSibling.click()"/>' +
			'<span style="font-size: 66%;">&nbsp;<label><input type="checkbox" id="yukiRemoveExif" onchange="yukiSetNewOptions(this);"' + (yukiRemoveExif ? ' checked' : '') + '> Убирать Exif</label> &nbsp;<label><input type="checkbox" id="yukiRemoveFileName" onchange="yukiSetNewOptions(this)"' + (yukiRemoveFileName ? ' checked' : '') + '> Убирать имя файла</label></span>' +
			'<div id="files_placeholder"></div></div></td></tr><tr style="display: none;" id="trgetback">' +
			'<td class="postblock"></td><td><select name="goto"><option value="board" selected="selected">доске</option><option value="thread">треду</option></select></td></tr></tbody></table>'
	*/}, null);
	
	document.head.parentNode.appendChild(body);
	$append(body, [
		delForm, 
		document.createElement("div").appendChild(mReplyForm),
		postCache]);
	$append(delForm, [
		thread,
		updater,
		playNotify,
		document.createElement("br"),
		autoUpdate,
		setUpdInt
	]);
	playNotify.insertAdjacentHTML('afterend', '<label>'+ LC.snd_notify +'</label>\n')
	autoUpdate.insertAdjacentHTML('afterend', '<label>'+ LC.updauto +'</label>\n')
	$after(thread, postCount);
	getHanabiraAllPosts(1);
	chek();
	
	var HM = {
		ExpImgs : {},
		ExpThreads : {},
		ReplyForm : null,
		LastReply : null,
		Refs : {},
		zIndex : 0,
		LoadedPosts : {},
		Highlighted : [],
		TextSize : 1.62
	};
	parseUrl = function (url) { 
		m = (url || document.location.href).match( /https?:\/\/([^\/]+)\/([^\/]+)\/((\d+)|res\/(\d+)|\w+)(\.x?html)?(#i?(\d+))?/)
		return m ? {host:m[1], board:m[2], page:m[4], thread:m[5], pointer:m[8]} : {} ;
	}
	
	BindCloseRef = function(reftab) {
		var closetr = document.createElement('tr');
		var close = $setup('td', {'style': 'padding-left:4px', 'html': '<span class="close icon"><img src="/images/blank.png"></span>'}, null);
		close.onclick = function() {reftab.remove()}
		closetr.appendChild(close);
		reftab.appendChild(closetr);
		reftab.onclick = function() {
			HM.Refs[reftab.style.zIndex = HM.zIndex++] = reftab;
		}
	}
	BindRemoveRef = function(binded, reftab) {
		var to;
		binded.onmouseout = function() {
			to = setTimeout(function() {reftab.remove()}, 300);
		}
		reftab.onmouseover = function() {
			clearTimeout(to);
		}
		reftab.onmouseout = function() {
			to = setTimeout(function() {reftab.remove()}, 300);
		}
	}
	toLoading = function(el) {
		return $setup(el, {'class': 'waiting' + Math.floor(Math.random() * 3) + ' icon', 'html': '<img src="/images/blank.png">'}, null);
	}
	InsertInto = function(textarea, text) {
		if (textarea.createTextRange && textarea.caretPos) {
			var caretPos = textarea.caretPos;
			caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == " " ? text + " " : text;
		} else if (textarea.setSelectionRange) {
			var start = textarea.selectionStart;
			var end = textarea.selectionEnd;
			textarea.value = textarea.value.substr(0, start) + text + textarea.value.substr(end);
			textarea.setSelectionRange(start + text.length, start + text.length);
		} else
			textarea.value += text + " ";
	}

	HM.Settings = !getlSValue('settings') ? setlSValue('settings', 3) : getlSValue('settings');
	HM.URL = parseUrl();
	
	var replies_links, replies_map = {}, link_template = '<a id="reply-link" href="/%board%/res/%thread%.xhtml#i%post%" onmouseover="ShowRefPost(event,\'%board%\', %thread%, %post%)" onclick="Highlight(event, \'%post%\')">&gt;&gt;%post%</a>';
	
	$setup('a', {'id': "reply-link", 'href':'/%board%/res/%thread%.xhtml#i%post%' })
	
	function ShowExRefPost(e, board, tid, pid) {
		var from, a = e.target,
			fa = a.parentNode.parentNode.parentNode.querySelector('.reflink a').getAttribute('href');
		var to0 = setTimeout(function() {
			var op = tid == pid;
			var postid = (op ? 'post_' : 'reply') + pid;
			var id = board + '-' + postid;
			var w = window.innerWidth;
			var x = e.pageX;
			var y = e.pageY + 30;
			var wx = w - x;
			replies_map = {};
			set_style = function(r, red) {
				if (red) {
					if (HM.Settings & 2) {
						var y2 = y - r.offsetHeight - 45;
						if (y2 > 0)
							y = y2;
					}
					if ((wx < 600 || wx < w / 2) && r.offsetWidth > wx) {
						var mw = w - 400;
						x = null;
					}
				}
				r.setAttribute('style', 'top: ' + y + 'px; max-width: ' + (mw || wx) + 'px; ' + (x == null ? 'right: 0' : 'left: ' + x) + 'px;');
			}
			var reftab = document.getElementById('ref' + id);
			if (reftab) {
				set_style(reftab, 1);
				reftab.onclick;
				return;
			}
			reftab = $setup('table', {'class': (op ? 'oppost popup' : 'popup'), 'id': 'ref' + id}, null);
			document.body.appendChild(reftab);
			set_style(reftab);
			var reftr = $setup('tr', {'id': 'load' + id}, null);
			var load = document.createElement('td');
			reftr.appendChild(load);
			reftab.appendChild(reftr);
			if (HM.Settings & 1)
				BindRemoveRef(a, reftab);
			var post = HM.LoadedPosts[id] || document.getElementById(postid);
			if (post) {
				//genReplyMap(replies_map, pid)
				load.innerHTML = (post.innerHTML || post);
				set_style(reftab, 2);
				if (!(HM.Settings & 1))
					BindCloseRef(reftab);
			} else if (HM.URL.thread == tid) {
				load.innerHTML = LC.postdel;
				if (!(HM.Settings & 1))
					BindRemoveRef(a, reftab);
			} else {
				//toLoading(load);
				getJsonPosts('/api/post/'+ board +'/'+ tid +'/'+ pid +'.json?message_html&new_format',
				function(status, sText, json, xhr) {
					var post = json.result;
					var post_addition = "";
					//genReplyMap(replies_map, pid)
					var temp = getHanabiraPost(post);
					postCache.appendChild($setup(temp[0], {'class': "cachedpost"}, null))
					load.className = '';
					node = op ? temp[0].innerHTML : temp[1].innerHTML;
					load.innerHTML = node;
					reftab.className = op ? 'oppost popup' : 'popup';
					if (node.indexOf('<') >= 0) {
						set_style(reftab, 2);
						if (!(HM.Settings & 1))
							BindCloseRef(reftab);
					} else if (!(HM.Settings & 1))
						BindRemoveRef(a, reftab);
				});
			}
			var from = reftab.querySelector('a[href="'+ fa +'"]');
			if (from){
				from.className = "reply-from";
				if (HM.Settings == 2)
					from.removeAttribute('onmouseover');
			}
		}, (HM.Settings & 2) ? 200 : 100);
		a.onmouseout = function() {
			clearTimeout(to0)
			if (from && HM.Settings != 2)
				from.removeAttribute('class');
		}
	}
	ShowRefPost = ShowExRefPost;
	
	wmarkText = function(openTag, closeTag) {
		var textArea = document.getElementById('yukireplyText');
		var len = textArea.value.length;
		var end = textArea.selectionEnd;
		var start = textArea.selectionStart;
		var selected = textArea.value.substring(start, end);
		cont = new RegExp(/^(\s*)(.*?)(\s*)$/).exec(selected);
		if (closeTag.slice(0, 1) == '\n')
			markedText = openTag + ( start === end ? window.getSelection().toString() : selected).replace(/\n/gm, closeTag);
		else if (cont == null) {
			var n = '', e = '';
			if (openTag.slice(0, 1) == '`')
				n = '\n', e = '`';
			else if (openTag.slice(0, 1) == '%')
				n = '\n';
			markedText = openTag + e + n + (start === end ? window.getSelection().toString() : selected) + n + e + closeTag;
		} else
			markedText = cont[1] + openTag + cont[2] + closeTag + cont[3];
		textArea.value = textArea.value.substring(0, start) + markedText + textArea.value.substring(end);
		textArea.focus();
		sOfs = '';
		eOfs = markedText.length;
		if (cont != null && cont[2] == '' && closeTag.slice(0, 1) != '\n') {
			sOfs = openTag.length;
			eOfs = sOfs + selected.length;
		}
		textArea.setSelectionRange(start + sOfs, start + eOfs);
		$setup(textArea, {'class': 'ta-inact'}, null);
		textArea.onclick = function() { this.removeAttribute('class') }
		window.onkeypress = function() {
			if (textArea.getAttribute('class') == 'ta-inact') {
				var sEn = textArea.selectionEnd;
				textArea.setSelectionRange(sEn, sEn);
				textArea.removeAttribute('class');
			}
		}
	}
	
	/*** yuki Multiple File Uploader ***/
	//* @ original code 	https://github.com/tranquility-yuki/yukiscript
	//* @ copyright 		2013+, You
	makeRandId = function(size) {
		var text = "";
		var possible = "0123456789abcdef";
		for (var i = 0; i < size; i++)
			text += possible.charAt(Math.floor(Math.random() * possible.length));
		return text;
	}
	
	arrayBufferDataUri = function(raw) {
		var base64 = ''
		var encodings = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
		var bytes = new Uint8Array(raw)
		var byteLength = bytes.byteLength
		var byteRemainder = byteLength % 3
		var mainLength = byteLength - byteRemainder
		var a, b, c, d
		var chunk
		// Main loop deals with bytes in chunks of 3
		for (var i = 0; i < mainLength; i = i + 3) {
			// Combine the three bytes into a single integer
			chunk = (bytes[i] << 16) | (bytes[i + 1] << 8) | bytes[i + 2]
			// Use bitmasks to extract 6-bit segments from the triplet
			a = (chunk & 16515072) >> 18 // 16515072 = (2^6 - 1) << 18
			b = (chunk & 258048) >> 12 // 258048 = (2^6 - 1) << 12
			c = (chunk & 4032) >> 6 // 4032 = (2^6 - 1) << 6
			d = chunk & 63 // 63 = 2^6 - 1
			// Convert the raw binary segments to the appropriate ASCII encoding
			base64 += encodings[a] + encodings[b] + encodings[c] + encodings[d]
		}
		// Deal with the remaining bytes and padding
		if (byteRemainder == 1) {
			chunk = bytes[mainLength]
			a = (chunk & 252) >> 2 // 252 = (2^6 - 1) << 2
			// Set the 4 least significant bits to zero
			b = (chunk & 3) << 4 // 3 = 2^2 - 1
			base64 += encodings[a] + encodings[b] + '=='
		} else if (byteRemainder == 2) {
			chunk = (bytes[mainLength] << 8) | bytes[mainLength + 1]
			a = (chunk & 64512) >> 10 // 16128 = (2^6 - 1) << 8
			b = (chunk & 1008) >> 4 // 1008 = (2^6 - 1) << 4
			// Set the 2 least significant bits to zero
			c = (chunk & 15) << 2 // 15 = 2^4 - 1
			base64 += encodings[a] + encodings[b] + encodings[c] + '='
		}
		return base64
	}
	
	jpegStripExtra = function(input) {
		// result e.target.result;
		// Decode the dataURL
		var binary = atob(input.split(',')[1]);
		// Create 8-bit unsigned array
		var array = [];
		for (var i = 0; i < binary.length; i++) {
			array.push(binary.charCodeAt(i));
		}
		var orig = new Uint8Array(array);
		var outData = new ArrayBuffer(orig.byteLength)
		var output = new Uint8Array(outData);
		var posO = 2,
			posT = 2;
		output[0] = orig[0];
		output[1] = orig[1];
		while (!(orig[posO] === 0xFF && orig[posO + 1] === 0xD9) && posO <= orig.byteLength) {
			if (orig[posO] === 0xFF && orig[posO + 1] === 0xFE) {
				posO += 2 + orig[posO + 2] * 256 + orig[posO + 3];
			} else if (orig[posO] === 0xFF && (orig[posO + 1] >> 4) === 0xE) {
				posO += 2 + orig[posO + 2] * 256 + orig[posO + 3];
			} else if (orig[posO] === 0xFF && orig[posO + 1] === 0xDA) {
				var l = (2 + orig[posO + 2] * 256 + orig[posO + 3]);
				for (var i = 0; i < l; i++) {
					output[posT++] = orig[posO++];
				}
				while (!(orig[posO] === 0xFF && orig[posO + 1] === 0xD9) && posO <= orig.byteLength) {
					output[posT++] = orig[posO++];
				}
			} else {
				var l = (2 + orig[posO + 2] * 256 + orig[posO + 3]);
				for (var i = 0; i < l; i++) {
					output[posT++] = orig[posO++];
				}
			}
		}
		output[posT] = orig[posO];
		output[posT + 1] = orig[posO + 1];
		output = new Uint8Array(outData, 0, posT + 2);
		return "data:image/Jpeg;base64," + arrayBufferDataUri(output);
	}
	
	difference = function(array1, array2) {
		var result = [];
		if (array2.length == 0) {
			return array1;
		};
		for (var i = 0; i < array1.length; i++) {
			if (array2.indexOf(array1[i]) == -1) {
				result.push(array1[i]);
			};
		};
		return result;
	}
	bytesMagnitude = function(bytes) {
		if (bytes < 1024)
			return bytes + ' B';
		else if (bytes < 1024 * 1024)
			return (bytes / 1024).toFixed(2) + ' KB';
		else
			return (bytes / 1024 / 1024).toFixed(2) + ' MB';
	}
	
	yukiAddFile = function(evt, b) {
		var fileList = [],
			yukiRemoveExif = true,
			yukiRemoveFileName = true;
		var files = evt.target.files; // FileList object
		if (fileList.length >= 5) {
			alert('Пять файлов это максимум на Доброчане.');
			return;
		}
		// Loop through the FileList and render image files as thumbnails.
		for (var i = 0, f; f = files[i]; i++) {
			if (fileList.length >= 5) {
				alert('Пять файлов это максимум на Доброчане.');
				break;
			}
			var f_name = f.name,
				renamed = false;
			if (yukiRemoveFileName) {
				f_name = (makeRandId(32) + (f.name.match(/\.[^\.]+$/) || [''])[0]).toLowerCase();
				renamed = true;
			}
			fileList.push({
				file: f,
				f_name: f_name,
				renamed: renamed,
				el: $setup('div', {'class': "yukiFile", 'html': '<span class="yuki_clickable">[убрать]</span><br><img class="preview_img" width="150px" src="" ></img><br/><span class="file_name">' +
					escape(f_name) + '</span><br/><span class="file_name">' +
					bytesMagnitude(f.size) + '&nbsp;</span><select name="file_1_rating" class="rating_SFW" onchange=\'$(this).attr("class", "").addClass("rating_" + $(this).children(":selected").val().replace("-",""));\'><option class="rating_SFW">SFW</option><option class="rating_R15">R-15</option><option class="rating_R18">R-18</option><option class="rating_R18G">R-18G</option></select></div>'}, null)
			});
			fileList[fileList.length - 1].el.querySelector('.yuki_clickable').onclick = (function(data) {
				return function(e) {
					var idx = fileList.indexOf(data);
					data.el.remove();
					delete fileList[idx];
					fileList.splice(idx, 1)
				}
			}(fileList[fileList.length - 1]))
			
			document.querySelector('#files_placeholder').appendChild(fileList[fileList.length - 1].el);
			var reader = new FileReader();
			// Closure to capture the file information.
			reader.onload = (function(theFile) {
				return function(e) {
					// Render thumbnail.
					if (yukiRemoveExif && theFile.file.type.toLowerCase() == 'image/jpeg') {
						theFile.dataURL = jpegStripExtra(e.target.result);
						theFile['jpegStripped'] = true;
					} else {
						theFile.dataURL = e.target.result;
						theFile['jpegStripped'] = false;
					}
					if (theFile.file.type.match('image.*')) {
						theFile.el.querySelector('.preview_img').setAttribute('src', theFile.dataURL);
					}
				};
			})(fileList[fileList.length - 1]);
			// Read in the image file as a data URL.
			reader.readAsDataURL(f);
		}
	}
	var yukiReplyForm = null,
		yukiRemoveExif = true,
		yukiRemoveFileName = true;
	function GetYukiReplyForm(click, board, tid, pid) {
		postform_tamplate = '<input name="thread_id" value="'+ tid +'" type="hidden"><input name="task" value="post" type="hidden"><input id="scroll_to" name="scroll_to" value="'+ pid +'" type="hidden">' +
			'<table><tbody><tr id="trname"><td class="postblock"></td><td><input name="name" size="30" placeholder="Анонимус" value="" type="text">' +
			'<span id="sage-btn" style="opacity:.4" onclick="$shide(this, \'opacity:.4\')"><img src="//ponyach.ru/css/images/niceroom.img/sage.svg"></span><span style="float:right">&nbsp;<a class="delete icon" title="Убрать" onclick="$shide(magicReplyForm, \'display:none\')" ><img src="/images/blank.png" alt="Remove" style="vertical-align:middle;min-height:17px"></a></span></td></tr><tr style="display:none" id="trsage"><td class="postblock"></td><td></td>' +
			'</tr><tr id="trsubject"><td class="postblock"></td><td><input name="subject" size="30" maxlength="64" placeholder="Тема" value="" type="text"><input name="new_post" value="Отправить" type="submit"><span style="float:right"><span class="markup-buttons" style="float:right;text-align:right">' +
			'<a href="#" onclick="wmarkText(\'* \', \'\\n* \');return false" class="list icon" title="Список" style="border:none">&nbsp;<strong>◉</strong>&nbsp;</a> '+
			'<a href="#" onclick="wmarkText(\'$~\', \'~$\');return false" class="strike icon" title="Зачеркнутый"><img src="/src/svg/1405/~S-mark.svg" alt="\~\$"></a> '+
			'<a href="#" onclick="wmarkText(\'_\', \'_\');return false" class="italic icon" title="Курсивный"><img src="/src/svg/1405/i-mark.svg" alt="i"></a> '+
			'<a href="#" onclick="wmarkText(\'**\', \'**\');return false" class="bold icon" title="Жирный"><img src="/src/svg/1405/-b-mark.svg" alt="b"></a> '+
			'<a href="#" onclick="wmarkText(\'`\', \'`\');return false" class="code icon" title="Код"><img src="/src/svg/1405/[c]-mark.svg" alt="c"></a> '+
			'<a href="#" onclick="wmarkText(\'%%\', \'%%\');return false" class="spoiler icon" title="Спойлер">·<strong>%%</strong>·</a> '+
			'<a href="#" onclick="wmarkText(\'> \', \'\\n> \');return false" class="quote icon" title="Цитировать выделенное"><img src="/src/svg/1405/„q”-mark.svg" alt="q"></a></span>' +
			'</td></tr><tr id="trmessage"><td class="postblock"></td><td><textarea placeholder="Текст сообщения " style="padding:0;resize:both" id="yukireplyText" name="message" cols="60" rows="6" onkeyup="$(this).css(\'height\', \'auto\' ); $(this).height(this.scrollHeight + 24);"></textarea><br/><div id="gamePlaceholder"></div></td></tr><tr id="trcaptcha"><td class="postblock"></td><td><span><img alt="Капча" id="captcha-image" src="/captcha/'+ desk +"/"+ $t() +'.png" onclick="reload_captcha(event)" style="margin:2px;vertical-align:middle">&nbsp;<span onclick="yukiAttachCapcha(this)" class="yuki_clickable" title="Прикрепить капчу" style="color:#999">[+]</span></span><br>' +
			'<input autocomplete="off" id="captcha" name="captcha" size="30" onfocus="reload_captcha(event);" onkeypress="CaptchaProcess(event, \'ru\')" type="text" style="display:none">' +
			'</td></tr><tr style="display: none;" id="trrempass"><td class="postblock"></td><td><input name="password" size="35" value="123" type="password">' +
			'</td></tr><tr id="trfile"><td class="postblock"></td><td id="files_parent"><input id="post_files_count" name="post_files_count" value="2" type="hidden">' +
			'<div id="file_1_div"><input id="dumb_file_field" onchange="yukiAddFile(event, this);" type="file" style="visiblity:hidden;width:0;height:0;position:absolute;left:-9001px" multiple>' +
			'<input value="Добавить файлы" type="button" onclick="this.previousElementSibling.click()"/>' +
			'<span style="font-size: 66%;">&nbsp;<label><input type="checkbox" id="yukiRemoveExif" onchange="yukiSetNewOptions(this);"' + (yukiRemoveExif ? ' checked' : '') + '> Убирать Exif</label> &nbsp;<label><input type="checkbox" id="yukiRemoveFileName" onchange="yukiSetNewOptions(this)"' + (yukiRemoveFileName ? ' checked' : '') + '> Убирать имя файла</label></span>' +
			'<div id="files_placeholder"></div></div></td></tr><tr style="display: none;" id="trgetback">' +
			'<td class="postblock"></td><td><select name="goto"><option value="board" selected="selected">доске</option><option value="thread">треду</option></select></td></tr></tbody></table>';
		magicReplyForm.onsubmit = function(){return yukiPleasePost()}
		upload_handler = $t() * 10000;
		//yukiReplyForm.find("input[name='password']").val($(".userdelete input[name='password']").val());
		//yukiReplyForm.find("input[name='name']").val($("#postform_placeholder input[name='name']").val());
		//if ($('#postFormDiv #captcha').length > 0) {
		//	yukiReplyForm.find("input[name='captcha']").show();
		//}
		var toPost = document.getElementById('post_'+ pid),
			nextEl = toPost.nextElementSibling;
		if (!nextEl || nextEl.id != 'magicpostform') {
			$after(toPost, $setup(magicReplyForm, {'html': postform_tamplate}, null));
		} else if (nextEl.id == 'magicpostform')
			$shide(magicReplyForm)
			InsertInto(document.getElementById('yukireplyText'), '>>'+ pid +'\n');
	}
	GetReplyForm = GetYukiReplyForm;
	document.head.appendChild($setup('script', {'type': 'text/javascript', 'src': "/src/js/1408/tinycon.min.js"}));
}







/*

	
	function getCookie(name) {
		var one, arr = document.cookie.split('; '),
			i = arr.length;
		while (i--) {
			one = arr[i].split('=');
			if (one[0] == escape(name)) return unescape(one[1]);
		}
		return false;
	}
	
	function setCookie(name, value) {
		document.cookie = escape(name) +
			'=' + escape(value) +
			';path=' + location.pathname +
			';expires=Mon, 01-Jan-2032 00:00:00 GMT';
	}
	

function getRelLink(num) {
	return '<a href="#' + num + '">&gt;&gt;' + num + '</a>';
}

function addRefMap(post) {
	post.querySelector('.message').insertAdjacentHTML('afterend',
		'<div class="de-refmap">' + post.ref.map(this).join(', ') + '</div>');
}

function genRefMap(posts, tUrl) {
	var refMap = [];
	Array.prototype.slice.call(posts, 0).forEach(function(post) {
		var msg = post.querySelector('.message');
		var ref = post.querySelector('.reflink');
		var pNum = $cid(post.id);
		for(var tc, link, lNum, lPost, i = 0, links = msg.querySelectorAll('a:not([href*="//"])'); link = links[i++];) {
			tc = link.textContent;
			if(tc.startsWith('>>') && (lNum = +tc.substr(2)) && (lPost = post[lNum])) {
				if(typeof lPost.ref === 'undefined') {
					lPost.ref = [pNum];
					refMap.push(lPost);
				} else if(lPost.ref.indexOf(pNum) === -1) {
					lPost.ref.push(pNum);
				}
			}
		}
	});
	refMap.forEach(addRefMap.bind(tUrl ? function(num) {
		return '<a href="' + tUrl + '#' + num + '">&gt;&gt;' + num + '</a>';
	} : getRelLink));
	refMap = tUrl = null;
	console.log(refMap)
}

function updRefMap(post, add) {
	for(var tc, ref, idx, link, lNum, lPost, pNum = post.num, i = 0, links = $T('a', post.msg); link = links[i++];) {
		tc = link.textContent;
		if(tc.startsWith('>>') && (lNum = +tc.substr(2)) && (lPost = pByNum[lNum])) {
			if(add) {
				if(typeof lPost.ref === 'undefined') {
					lPost.ref = [pNum];
				} else if(lPost.ref.indexOf(pNum) === -1) {
					lPost.ref.push(pNum);
				} else {
					continue;
				}
				if(Cfg['hideRefPsts'] && lPost.hide) {
					hidePost(post, 'reference to >>' + lNum);
				}
			} else if((ref = lPost.ref) && (idx = ref.indexOf(pNum)) !== -1) {
				ref.splice(idx, 1);
				if(ref.length === 0) {
					lPost.ref = void 0;
					$del($c('de-refmap', lPost));
					continue;
				}
			}
			$del($c('de-refmap', lPost));
			addRefMap.call(getRelLink, lPost);
			eventRefLink($c('de-refmap', lPost));
		}
	}
}*/


